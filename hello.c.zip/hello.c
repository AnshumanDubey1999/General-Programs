#include<stdio.h>
#include<math.h>

int main()
{
    int t;
    scanf("%d", &t);
    while(t--)
    {
        double a,b,c;
        int ans;

        scanf("%lf %lf", &b,&c);

        a = ceil(sqrt(b*b + c*c));

        ans = a;
        printf("%d", ans);
    }

    return 0;
}